from flask import Flask, request, send_file, render_template, jsonify
import os
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageEnhance, ImageFilter
import tempfile
import logging
import base64
from io import BytesIO
from werkzeug.utils import secure_filename
import requests

# Set up logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Initialize the Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET")

# Create necessary folders
UPLOAD_FOLDER = 'uploads'
RESULT_FOLDER = 'results'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(RESULT_FOLDER, exist_ok=True)

# Allowed file extensions
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}

def allowed_file(filename):
    """Check if the file has an allowed extension"""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Function to enhance images locally using PIL
def enhance_locally(image_data, style='standard'):
    """Apply local image enhancement using PIL
    
    Args:
        image_data: The binary image data
        style: The enhancement style - 'standard' or 'ghibli'
    
    Returns:
        Base64 encoded enhanced image
    """
    logger.info(f"Applying local image enhancement with style: {style}")
    
    # Open the image data
    img = Image.open(BytesIO(image_data))
    
    # Convert to RGB mode if needed (remove alpha channel)
    if img.mode in ('RGBA', 'LA'):
        background = Image.new('RGB', img.size, 'white')
        background.paste(img, mask=img.split()[-1])
        img = background
    
    if style == 'ghibli':
        # Apply Ghibli-inspired cartoon-like effects
        logger.info("Applying anime-style enhancement")
        
        # First, increase color saturation for vibrant colors
        enhancer = ImageEnhance.Color(img)
        img = enhancer.enhance(1.6)  # More saturation for anime look
        
        # Apply edge enhancement multiple times for cartoon-like outlines
        img = img.filter(ImageFilter.EDGE_ENHANCE_MORE)
        img = img.filter(ImageFilter.EDGE_ENHANCE)
        
        # Apply smoothing to create the soft painterly effect
        img = img.filter(ImageFilter.SMOOTH_MORE)
        
        # Increase contrast for more definition
        enhancer = ImageEnhance.Contrast(img)
        img = enhancer.enhance(1.5)
        
        # Slight brightness adjustment
        enhancer = ImageEnhance.Brightness(img)
        img = enhancer.enhance(1.15)
        
        # Add watermark
        draw = ImageDraw.Draw(img)
        try:
            font = ImageFont.truetype("arial.ttf", 36)
        except IOError:
            # Use default font if arial.ttf not available
            font = ImageFont.load_default()
        draw.text((10, img.height - 50), "Developed by Hassan", fill=(255, 255, 255))
        
    else:
        # Standard enhancement
        logger.info("Applying standard enhancement")
        
        # Sharpen the image
        enhancer = ImageEnhance.Sharpness(img)
        img = enhancer.enhance(2.0)  # Increase sharpness
        
        # Increase color saturation
        enhancer = ImageEnhance.Color(img)
        img = enhancer.enhance(1.3)  # Slightly increase color
        
        # Increase contrast
        enhancer = ImageEnhance.Contrast(img)
        img = enhancer.enhance(1.3)  # Slightly increase contrast
        
        # Increase brightness
        enhancer = ImageEnhance.Brightness(img)
        img = enhancer.enhance(1.1)  # Slightly increase brightness
        
        # Apply a subtle edge enhancement
        img = img.filter(ImageFilter.EDGE_ENHANCE)
        
        # Add watermark
        draw = ImageDraw.Draw(img)
        try:
            font = ImageFont.truetype("arial.ttf", 36)
        except IOError:
            # Use default font if arial.ttf not available
            font = ImageFont.load_default()
        draw.text((10, img.height - 50), "Developed by Hassan", fill=(255, 255, 255))
    
    # Save to a buffer and return
    buffer = BytesIO()
    img.save(buffer, format='JPEG', quality=95)
    return buffer.getvalue()

@app.route('/')
def index():
    """Render the home page"""
    return render_template('index.html')

@app.route('/enhance', methods=['POST'])
def enhance_image():
    """Process and enhance the uploaded image using AI models or local processing"""
    if 'image' not in request.files:
        return jsonify({"error": "No image file provided"}), 400

    file = request.files['image']

    if file.filename == '':
        return jsonify({"error": "No image selected"}), 400

    if not allowed_file(file.filename):
        return jsonify({"error": "Invalid file format. Only JPEG and PNG files are allowed"}), 400

    try:
        # Save the uploaded image to a temporary file
        with tempfile.NamedTemporaryFile(delete=False, suffix=os.path.splitext(secure_filename(file.filename))[1]) as temp:
            file.save(temp.name)
            temp_filename = temp.name

        # Verify the image can be opened
        try:
            img = Image.open(temp_filename)
            img.verify()  # Verify the image is valid
        except Exception as e:
            os.unlink(temp_filename)
            logger.error(f"Invalid image file: {e}")
            return jsonify({"error": "The uploaded file is not a valid image"}), 400

        # Read the file data
        with open(temp_filename, "rb") as image_file:
            image_data = image_file.read()
        
        # Clean up the temporary file
        os.unlink(temp_filename)
        
        # Get the style parameter if provided
        style = request.form.get('style', 'standard')
        
        # Save to permanent storage if requested
        save_result = request.form.get('save', 'false').lower() == 'true'
        
        try:
            # Enhance the image locally
            enhanced_data = enhance_locally(image_data, style=style)
            
            # Save the result if requested
            if save_result:
                result_filename = f"enhanced_{secure_filename(file.filename)}"
                result_path = os.path.join(RESULT_FOLDER, result_filename)
                with open(result_path, 'wb') as f:
                    f.write(enhanced_data)
                logger.info(f"Saved enhanced image to {result_path}")
            
            # Return as attachment if download requested, otherwise as JSON
            if request.form.get('download', 'false').lower() == 'true':
                return send_file(
                    BytesIO(enhanced_data),
                    mimetype='image/jpeg',
                    as_attachment=True,
                    download_name=f"enhanced_{secure_filename(file.filename)}"
                )
            else:
                # Convert to base64 for sending back to the client
                enhanced_base64 = base64.b64encode(enhanced_data).decode('utf-8')
                return jsonify({
                    "success": True,
                    "enhanced_image": enhanced_base64,
                    "style": style
                })
                
        except Exception as e:
            logger.error(f"Error during image enhancement: {e}")
            return jsonify({"error": f"Image enhancement failed: {str(e)}"}), 500
        
    except Exception as e:
        logger.error(f"Error processing the image: {e}")
        return jsonify({"error": f"Failed to process image: {str(e)}"}), 500

# This is commented out as we can't easily install gfpgan in Replit,
# but it's here for documentation of what the user would need for GFPGAN support
"""
try:
    import torch
    from gfpgan import GFPGANer
    
    # Check if GFPGAN model is available
    model_path = 'GFPGANv1.3.pth'
    GFPGAN_AVAILABLE = os.path.exists(model_path)
    
    if GFPGAN_AVAILABLE:
        # Load the GFPGAN model
        restorer = GFPGANer(
            model_path=model_path,
            upscale=2,
            arch='clean',
            channel_multiplier=2,
            bg_upsampler=None
        )
        logger.info("GFPGAN model loaded successfully")
    else:
        logger.warning(f"GFPGAN model not found at {model_path}")
        
except ImportError:
    logger.warning("GFPGAN libraries not installed")
    GFPGAN_AVAILABLE = False
"""

@app.route('/download/<path:filename>')
def download_file(filename):
    """Download a saved enhanced image"""
    try:
        return send_file(
            os.path.join(RESULT_FOLDER, filename),
            as_attachment=True
        )
    except Exception as e:
        logger.error(f"Error downloading file: {e}")
        return jsonify({"error": "File not found"}), 404

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)