import os
import logging
import requests
import replicate
import tempfile
import base64
from flask import Flask, render_template, request, jsonify
from PIL import Image, ImageFilter, ImageEnhance
from io import BytesIO
from werkzeug.utils import secure_filename

# Set up logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Initialize the Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET")

# Add cache headers
@app.after_request
def add_header(response):
    response.cache_control.max_age = 300
    return response

# Configure Replicate API
REPLICATE_API_TOKEN = os.environ.get("REPLICATE_API_TOKEN")
if not REPLICATE_API_TOKEN:
    logger.warning("REPLICATE_API_TOKEN not set in environment variables")

# Allowed file extensions
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}

def allowed_file(filename):
    """Check if the file has an allowed extension"""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/')
def index():
    """Render the home page"""
    return render_template('index.html')

def enhance_locally(image_data, style='standard'):
    """Apply local image enhancement using PIL
    
    Args:
        image_data: The binary image data
        style: The enhancement style - 'standard' or 'ghibli'
    
    Returns:
        Base64 encoded enhanced image
    """
    logger.info(f"Applying local image enhancement with style: {style}")
    
    # Open the image data
    img = Image.open(BytesIO(image_data))
    
    # Convert to RGB mode if needed (remove alpha channel)
    if img.mode in ('RGBA', 'LA'):
        background = Image.new('RGB', img.size, 'white')
        background.paste(img, mask=img.split()[-1])
        img = background
    
    if style == 'ghibli':
        # Apply Ghibli-inspired cartoon-like effects
        logger.info("Applying anime-style enhancement")
        
        # First, increase color saturation for vibrant colors
        enhancer = ImageEnhance.Color(img)
        img = enhancer.enhance(1.6)  # More saturation for anime look
        
        # Apply edge enhancement multiple times for cartoon-like outlines
        img = img.filter(ImageFilter.EDGE_ENHANCE_MORE)
        img = img.filter(ImageFilter.EDGE_ENHANCE)
        
        # Apply smoothing to create the soft painterly effect
        img = img.filter(ImageFilter.SMOOTH_MORE)
        
        # Increase contrast for more definition
        enhancer = ImageEnhance.Contrast(img)
        img = enhancer.enhance(1.5)
        
        # Slight brightness adjustment
        enhancer = ImageEnhance.Brightness(img)
        img = enhancer.enhance(1.15)
        
    else:
        # Standard enhancement
        logger.info("Applying standard enhancement")
        
        # Sharpen the image
        enhancer = ImageEnhance.Sharpness(img)
        img = enhancer.enhance(2.0)  # Increase sharpness
        
        # Increase color saturation
        enhancer = ImageEnhance.Color(img)
        img = enhancer.enhance(1.3)  # Slightly increase color
        
        # Increase contrast
        enhancer = ImageEnhance.Contrast(img)
        img = enhancer.enhance(1.3)  # Slightly increase contrast
        
        # Increase brightness
        enhancer = ImageEnhance.Brightness(img)
        img = enhancer.enhance(1.1)  # Slightly increase brightness
        
        # Apply a subtle edge enhancement
        img = img.filter(ImageFilter.EDGE_ENHANCE)
    
    # Save to a buffer and return as base64
    buffer = BytesIO()
    img.save(buffer, format='JPEG', quality=95)
    return base64.b64encode(buffer.getvalue()).decode('utf-8')

@app.route('/enhance', methods=['POST'])
def enhance_image():
    """Process and enhance the uploaded image using AI models via Replicate API
    or fall back to local enhancement if API options fail"""
    if 'image' not in request.files:
        return jsonify({"error": "No image file provided"}), 400

    file = request.files['image']

    if file.filename == '':
        return jsonify({"error": "No image selected"}), 400

    if not allowed_file(file.filename):
        return jsonify({"error": "Invalid file format. Only JPEG and PNG files are allowed"}), 400

    try:
        # Save the uploaded image to a temporary file
        with tempfile.NamedTemporaryFile(delete=False, suffix=os.path.splitext(secure_filename(file.filename))[1]) as temp:
            file.save(temp.name)
            temp_filename = temp.name

        # Verify the image can be opened
        try:
            img = Image.open(temp_filename)
            img.verify()  # Verify the image is valid
        except Exception as e:
            os.unlink(temp_filename)
            logger.error(f"Invalid image file: {e}")
            return jsonify({"error": "The uploaded file is not a valid image"}), 400

        # Read the file data
        with open(temp_filename, "rb") as image_file:
            image_data = image_file.read()
            encoded_string = base64.b64encode(image_data).decode('utf-8')
        
        # Clean up the temporary file
        os.unlink(temp_filename)
        
        # Get the model selection from the form
        model_id = request.form.get('model', 'default')
        logger.info(f"Using model: {model_id}")
        
        # Check if local processing is explicitly requested
        if model_id == 'local':
            # Get the style parameter if provided
            style = request.form.get('style', 'standard')
            logger.info(f"Local processing explicitly requested with style: {style}")
            enhanced_base64 = enhance_locally(image_data, style=style)
            return jsonify({
                "success": True,
                "enhanced_image": enhanced_base64,
                "model_used": "local",
                "style": style
            })
        
        # Try AI models if API token is available
        if REPLICATE_API_TOKEN:
            # Set the Replicate API token
            replicate.api_token = REPLICATE_API_TOKEN
            
            try:
                # First try with specified model
                if model_id == 'default' or model_id == 'gfpgan':
                    logger.info("Attempting enhancement with GFPGAN model")
                    output = replicate.run(
                        "tencentarc/gfpgan:9283608cc6b7be6b65a8e44983db012355fde4132009bf99d976b2f0896856a3",
                        input={"img": encoded_string}
                    )
                elif model_id == 'free':
                    logger.info("Attempting enhancement with Real-ESRGAN model")
                    output = replicate.run(
                        "nightmareai/real-esrgan:42fed1c4974146d4d2414e2be2c5277c7fcf05fcc3a73abf41610695738c1d7b",
                        input={"image": encoded_string}
                    )
                
                # If we get here and have output, process it
                if output:
                    logger.info(f"AI model returned output URL: {output}")
                    response = requests.get(output)
                    if response.status_code == 200:
                        enhanced_base64 = base64.b64encode(response.content).decode('utf-8')
                        return jsonify({
                            "success": True,
                            "enhanced_image": enhanced_base64,
                            "model_used": model_id
                        })
                    else:
                        logger.warning(f"Failed to fetch AI model output, status code: {response.status_code}")
            except Exception as e:
                logger.error(f"AI model error: {str(e)}")
                # Continue to local fallback
        else:
            logger.warning("No Replicate API token available, skipping AI models")
        
        # If we reach here, either AI processing failed or was not available
        # Fall back to local processing
        # Get the style parameter if provided
        style = request.form.get('style', 'standard')
        logger.info(f"Falling back to local image enhancement with style: {style}")
        enhanced_base64 = enhance_locally(image_data, style=style)
        
        return jsonify({
            "success": True,
            "enhanced_image": enhanced_base64,
            "model_used": "local",
            "style": style,
            "note": "Used local enhancement as AI models were unavailable or failed"
        })
        
    except Exception as e:
        logger.error(f"Error during image enhancement: {e}")
        return jsonify({"error": f"Failed to enhance image: {str(e)}"}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)