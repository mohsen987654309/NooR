document.addEventListener('DOMContentLoaded', function() {
    // Elements
    const uploadForm = document.getElementById('upload-form');
    const imageInput = document.getElementById('image-input');
    const uploadArea = document.querySelector('.upload-area');
    const uploadPrompt = document.getElementById('upload-prompt');
    const previewContainer = document.getElementById('preview-container');
    const imagePreview = document.getElementById('image-preview');
    const fileName = document.getElementById('file-name');
    const removeImageBtn = document.getElementById('remove-image');
    const enhanceBtn = document.getElementById('enhance-btn');
    const modelSelect = document.getElementById('model-select');
    const processingSection = document.getElementById('processing');
    const processingMessage = document.getElementById('processing-message');
    const errorMessage = document.getElementById('error-message');
    const resultsContainer = document.getElementById('results-container');
    const originalImage = document.getElementById('original-image');
    const enhancedImage = document.getElementById('enhanced-image');
    const downloadBtn = document.getElementById('download-btn');
    const startOverBtn = document.getElementById('start-over-btn');
    const ghibliBtn = document.getElementById('ghibli-btn'); // Added Ghibli button element

    // Current file being processed
    let currentFile = null;

    // Event Listeners
    imageInput.addEventListener('change', handleFileSelect);
    removeImageBtn.addEventListener('click', resetUpload);
    uploadForm.addEventListener('submit', processImage);
    downloadBtn.addEventListener('click', downloadEnhancedImage);
    startOverBtn.addEventListener('click', startOver);
    ghibliBtn.addEventListener('click', ghibliStyle); //Added event listener for Ghibli button


    // Drag and drop functionality
    uploadArea.addEventListener('dragover', function(e) {
        e.preventDefault();
        uploadArea.classList.add('dragover');
    });

    uploadArea.addEventListener('dragleave', function() {
        uploadArea.classList.remove('dragover');
    });

    uploadArea.addEventListener('drop', function(e) {
        e.preventDefault();
        uploadArea.classList.remove('dragover');

        if (e.dataTransfer.files.length) {
            imageInput.files = e.dataTransfer.files;
            handleFileSelect();
        }
    });

    // Handle file selection
    function handleFileSelect() {
        const file = imageInput.files[0];

        if (!file) return;

        // Check file type
        const validTypes = ['image/jpeg', 'image/jpg', 'image/png'];
        if (!validTypes.includes(file.type)) {
            showError('Please select a valid image file (JPEG or PNG).');
            resetUpload();
            return;
        }

        // Store the current file
        currentFile = file;

        // Update UI
        uploadPrompt.classList.add('d-none');
        previewContainer.classList.remove('d-none');
        fileName.textContent = file.name;
        enhanceBtn.disabled = false;
        ghibliBtn.disabled = false; // Enable Ghibli button

        // Show image preview
        const reader = new FileReader();
        reader.onload = function(e) {
            imagePreview.src = e.target.result;
        };
        reader.readAsDataURL(file);

        // Hide any previous error or results
        hideError();
        resultsContainer.classList.add('d-none');
    }

    // Reset upload area
    function resetUpload() {
        uploadPrompt.classList.remove('d-none');
        previewContainer.classList.add('d-none');
        imagePreview.src = '';
        fileName.textContent = '';
        imageInput.value = '';
        enhanceBtn.disabled = true;
        ghibliBtn.disabled = true; // Disable Ghibli button
        currentFile = null;
    }

    // Process image with AI
    async function compressImage(file) {
    return new Promise((resolve) => {
        const reader = new FileReader();
        reader.onload = function(e) {
            const img = new Image();
            img.onload = function() {
                const canvas = document.createElement('canvas');
                const ctx = canvas.getContext('2d');
                const maxWidth = 1600;
                const maxHeight = 1600;
                let width = img.width;
                let height = img.height;

                if (width > height && width > maxWidth) {
                    height *= maxWidth / width;
                    width = maxWidth;
                } else if (height > maxHeight) {
                    width *= maxHeight / height;
                    height = maxHeight;
                }

                canvas.width = width;
                canvas.height = height;
                ctx.drawImage(img, 0, 0, width, height);

                canvas.toBlob((blob) => {
                    resolve(new File([blob], file.name, {
                        type: 'image/jpeg',
                        lastModified: Date.now()
                    }));
                }, 'image/jpeg', 0.8);
            };
            img.src = e.target.result;
        };
        reader.readAsDataURL(file);
    });
}

async function processImage(e) {
        e.preventDefault();

        if (!currentFile) {
            showError('Please select an image first.');
            return;
        }

        // Show processing spinner
        processingSection.classList.remove('d-none');
        enhanceBtn.disabled = true;
        ghibliBtn.disabled = true; // Disable Ghibli button during processing
        hideError();

        // Compress image before upload
        const compressedFile = await compressImage(currentFile);

        // Update processing message based on selected model
        processingMessage.textContent = `Enhancing your photo...`;

        // Create FormData with compressed image
        const formData = new FormData();
        formData.append('image', compressedFile);
        formData.append('model', modelSelect.value);

        // Send to server
        fetch('/enhance', {
            method: 'POST',
            body: formData
        })
        .then(response => {
            if (!response.ok) {
                return response.json().then(data => {
                    throw new Error(data.error || 'Failed to process image');
                });
            }
            return response.json();
        })
        .then(data => {
            if (data.success) {
                displayResults(data.enhanced_image);
            } else {
                throw new Error(data.error || 'Unknown error occurred');
            }
        })
        .catch(error => {
            // Check if this is a billing error
            if (error.message.includes('billing') || error.message.includes('402')) {
                showError('This AI model requires billing setup. Please contact the administrator.');
            } else if (error.message.includes('API token')) {
                showError('API configuration is missing. Please check the setup.');
            } else {
                showError(error.message || 'An unexpected error occurred. Please try again.');
            }
            processingSection.classList.add('d-none');
            enhanceBtn.disabled = false;
            ghibliBtn.disabled = false; // Re-enable Ghibli button on error
        });
    }

    // Display results
    function displayResults(enhancedImageData) {
        // Hide processing spinner
        processingSection.classList.add('d-none');

        // Set the images
        originalImage.src = imagePreview.src;
        enhancedImage.src = `data:image/jpeg;base64,${enhancedImageData}`;

        // Show results section
        resultsContainer.classList.remove('d-none');

        // Scroll to results
        resultsContainer.scrollIntoView({ behavior: 'smooth' });
    }

    // Download enhanced image
    function downloadEnhancedImage() {
        if (enhancedImage.src) {
            const link = document.createElement('a');
            link.href = enhancedImage.src;
            link.download = 'enhanced-' + (currentFile ? currentFile.name : 'image.jpg');
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }
    }

    // Start over with a new image
    function startOver() {
        resetUpload();
        resultsContainer.classList.add('d-none');
        uploadArea.scrollIntoView({ behavior: 'smooth' });
    }

    // Show error message
    function showError(message) {
        errorMessage.textContent = message;
        errorMessage.classList.remove('d-none');
    }

    // Hide error message
    function hideError() {
        errorMessage.textContent = '';
        errorMessage.classList.add('d-none');
    }

    async function ghibliStyle(e) {
        if (e) e.preventDefault();
        
        if (!currentFile) {
            showError('Please select an image first.');
            return;
        }

        // Show processing spinner
        processingSection.classList.remove('d-none');
        processingMessage.textContent = "Applying Ghibli-style enhancement...";
        enhanceBtn.disabled = true;
        ghibliBtn.disabled = true;
        hideError();

        // Compress image before upload
        const compressedFile = await compressImage(currentFile);

        // Create FormData with compressed image
        const formData = new FormData();
        formData.append('image', compressedFile);
        formData.append('model', 'local');  // Use local processing for Ghibli style
        formData.append('style', 'ghibli');

        // Send to server
        fetch('/enhance', {
            method: 'POST',
            body: formData
        })
        .then(response => {
            if (!response.ok) {
                return response.json().then(data => {
                    throw new Error(data.error || 'Failed to process image');
                });
            }
            return response.json();
        })
        .then(data => {
            if (data.success) {
                displayResults(data.enhanced_image);
            } else {
                throw new Error(data.error || 'Unknown error occurred');
            }
        })
        .catch(error => {
            showError(error.message || 'An unexpected error occurred. Please try again.');
            processingSection.classList.add('d-none');
            enhanceBtn.disabled = false;
            ghibliBtn.disabled = false;
        });
    }
});